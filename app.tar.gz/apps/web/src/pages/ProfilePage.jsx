
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ExternalLink, Clock, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import pb from '@/lib/pocketbaseClient.js';

const ProfilePage = () => {
  const { slug } = useParams();
  const [user, setUser] = useState(null);
  const [links, setLinks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchProfile();
  }, [slug]);

  const fetchProfile = async () => {
    try {
      setLoading(true);
      setError(null);

      const userRecord = await pb.collection('usuarios').getFirstListItem(
        `slug="${slug}"`,
        { $autoCancel: false }
      );
      setUser(userRecord);

      if (userRecord.status === 1) {
        const linksRecords = await pb.collection('links').getList(1, 100, {
          filter: `usuario_id="${userRecord.id}"`,
          sort: 'ordem',
          $autoCancel: false
        });
        setLinks(linksRecords.items);
      }
    } catch (err) {
      console.error('Error fetching profile:', err);
      setError('Perfil não encontrado');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Loader2 className="h-12 w-12 text-primary animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground font-medium">Carregando perfil...</p>
        </div>
      </div>
    );
  }

  if (error || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <div className="text-center max-w-md mx-auto glass-card p-10 rounded-3xl">
          <div className="bg-destructive/10 rounded-full w-24 h-24 mx-auto mb-6 flex items-center justify-center">
            <ExternalLink className="h-10 w-10 text-destructive" />
          </div>
          <h1 className="text-3xl font-heading font-bold mb-4">Perfil não encontrado</h1>
          <p className="text-muted-foreground mb-8">
            O perfil que você está procurando não existe ou foi removido.
          </p>
          <Button
            onClick={() => window.location.href = '/'}
            className="w-full"
          >
            Voltar para o início
          </Button>
        </div>
      </div>
    );
  }

  // User is awaiting activation
  if (user.status === 0) {
    return (
      <>
        <Helmet>
          <title>{`@${user.slug} - contate.site`}</title>
          <meta name="description" content={`Perfil de ${user.slug} no contate.site`} />
        </Helmet>

        <div 
          className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden"
          style={{ backgroundColor: user.cor_fundo || '#ffffff' }}
        >
          {/* Subtle overlay to ensure contrast */}
          <div className="absolute inset-0 bg-black/5 dark:bg-black/20 backdrop-blur-[2px]"></div>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="text-center max-w-md mx-auto relative z-10"
          >
            <div className="bg-white/80 dark:bg-black/60 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/20 p-12">
              <div className="bg-accent/20 rounded-full w-24 h-24 mx-auto mb-6 flex items-center justify-center">
                <Clock className="h-10 w-10 text-accent" />
              </div>
              <h1 className="text-3xl font-heading font-bold mb-4 text-foreground">Aguardando Ativação</h1>
              <p className="text-muted-foreground text-lg">
                Este perfil está em processo de ativação e estará disponível em breve.
              </p>
            </div>
          </motion.div>
        </div>
      </>
    );
  }

  // User is active - show profile with links
  return (
    <>
      <Helmet>
        <title>{`@${user.slug} - contate.site`}</title>
        <meta name="description" content={`Confira todos os links de ${user.slug} em um só lugar`} />
      </Helmet>

      <div 
        className="min-h-screen py-20 px-4 relative overflow-hidden"
        style={{ backgroundColor: user.cor_fundo || '#ffffff' }}
      >
        {/* Subtle gradient overlay for premium feel */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/0 via-black/5 to-black/10 dark:from-black/20 dark:via-black/40 dark:to-black/60 pointer-events-none"></div>

        <div className="max-w-2xl mx-auto relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="text-center mb-12"
          >
            <div className="bg-white/20 dark:bg-black/20 backdrop-blur-md p-2 rounded-full w-32 h-32 mx-auto mb-6 shadow-2xl border border-white/30">
              <div className="bg-gradient-to-br from-primary to-secondary w-full h-full rounded-full flex items-center justify-center">
                <span className="text-5xl font-heading font-bold text-white">
                  {user.slug.charAt(0).toUpperCase()}
                </span>
              </div>
            </div>
            <h1 className="text-4xl md:text-5xl font-heading font-bold mb-3 text-foreground drop-shadow-sm">
              @{user.slug}
            </h1>
            <p className="text-foreground/80 text-lg font-medium">
              Confira meus links abaixo
            </p>
          </motion.div>

          {links.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-center py-12"
            >
              <div className="bg-white/50 dark:bg-black/40 backdrop-blur-xl rounded-3xl shadow-lg border border-white/20 p-10">
                <p className="text-foreground/70 text-lg font-medium">
                  Nenhum link disponível no momento
                </p>
              </div>
            </motion.div>
          ) : (
            <div className="space-y-5">
              {links.map((link, index) => (
                <motion.a
                  key={link.id}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="block group"
                >
                  <div className="w-full flex items-center justify-between py-5 px-8 text-lg font-semibold bg-white/70 dark:bg-black/50 backdrop-blur-xl border border-white/30 dark:border-white/10 text-foreground rounded-2xl shadow-lg hover:shadow-2xl hover:scale-[1.02] hover:bg-white/90 dark:hover:bg-black/70 transition-all duration-300">
                    <span className="flex-1 text-center truncate px-4">{link.titulo}</span>
                    <ExternalLink className="h-5 w-5 opacity-50 group-hover:opacity-100 group-hover:translate-x-1 transition-all shrink-0" />
                  </div>
                </motion.a>
              ))}
            </div>
          )}

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="text-center mt-16"
          >
            <a 
              href="/" 
              className="inline-flex items-center gap-2 text-sm font-medium text-foreground/60 hover:text-foreground bg-white/20 dark:bg-black/20 backdrop-blur-md px-4 py-2 rounded-full transition-colors"
            >
              Powered by <span className="font-bold">contate.site</span>
            </a>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default ProfilePage;
